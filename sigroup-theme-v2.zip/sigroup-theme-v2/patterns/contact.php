<?php
/**
 * Title: Contact
 * Slug: sigroup-theme/contact
 * Categories: page
 */
?>
<!-- wp:html -->
<div class="page-header">
  <div class="page-header-inner">
    <div>
      <span class="section-en">Contact</span>
      <span class="section-ja">お問い合わせ</span>
      <p>事業相談・採用相談を一括受付しています。内容に応じて担当よりご案内します。</p>
    </div>
    <div class="page-header-img">
      <img src="https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1000&h=560&fit=crop" alt="相談イメージ" width="1000" height="560" loading="lazy">
    </div>
  </div>
</div>

<section class="section section--white">
  <div class="container">
    <span class="section-en">Get in touch</span>
    <span class="section-ja">ご連絡方法</span>
    <div class="contact-grid">
      <div class="contact-card">
        <h3>事業相談</h3>
        <p>営業代行・人材派遣・業務効率化など、事業に関するご相談はこちら。</p>
        <p style="margin-top:1rem;"><strong>📧 メール</strong><br>business@si-group-inc.com</p>
        <p style="margin-top:0.75rem;"><strong>📞 電話</strong><br>06-1234-5678<br><small style="color:var(--text-faint);">平日 9:00〜18:00</small></p>
      </div>
      <div class="contact-card">
        <h3>所在地 / アクセス</h3>
        <p><strong>〒542-0081</strong><br>大阪府大阪市中央区<br>南船場二丁目1番3号</p>
        <p style="margin-top:1rem;">地下鉄御堂筋線「心斎橋駅」より徒歩5分</p>
      </div>
    </div>
  </div>
</section>

<section class="section section--offwhite">
  <div class="container">
    <div class="two-col">
      <div class="two-col-image">
        <img src="https://images.unsplash.com/photo-1553877522-43269d4ea984?w=900&h=675&fit=crop" alt="オフィス外観" width="900" height="675" loading="lazy">
      </div>
      <div>
        <span class="section-en">Working Hours</span>
        <span class="section-ja">営業時間</span>
        <div class="info-table-wrap">
          <table class="info-table">
            <tr><th>平日</th><td>9:00〜18:00</td></tr>
            <tr><th>土日祝</th><td>休業</td></tr>
            <tr><th>年末年始</th><td>12月29日〜1月3日 休業</td></tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /wp:html -->
