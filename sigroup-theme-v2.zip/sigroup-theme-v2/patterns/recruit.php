<?php
/**
 * Title: Recruit
 * Slug: sigroup-theme/recruit
 * Categories: page
 */
?>
<!-- wp:html -->
<div class="page-header">
  <div class="page-header-inner">
    <div>
      <span class="section-en">Recruit</span>
      <span class="section-ja">採用情報</span>
      <p>柔軟な働き方と、成長できる環境を両立する。リモートワーク可・副業OK・フレックスタイム制。</p>
    </div>
    <div class="page-header-img">
      <img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=1000&h=560&fit=crop" alt="チームで働くメンバー" width="1000" height="560" loading="lazy">
    </div>
  </div>
</div>

<section class="section section--white">
  <div class="container">
    <span class="section-en">Environment</span>
    <span class="section-ja">働く環境</span>
    <div class="feature-grid">
      <div class="feature-card">
        <div class="feature-icon">
          <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        </div>
        <h3>リモートワーク可</h3>
        <p>職種により在宅勤務・出社のハイブリッド勤務が選択可能です。</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        </div>
        <h3>フレックスタイム制</h3>
        <p>コアタイムなしのフルフレックス制度を導入しています。</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
        </div>
        <h3>副業OK</h3>
        <p>事前申請により副業・兼業が可能です。多様なキャリア形成を支援します。</p>
      </div>
    </div>
  </div>
</section>

<section class="section section--offwhite">
  <div class="container">
    <span class="section-en">Positions</span>
    <span class="section-ja">募集職種</span>
    <div class="policy-list">
      <div class="policy-item">
        <span class="policy-num">01</span>
        <div>
          <h4>営業職（正社員・契約社員）</h4>
          <p>新規開拓営業、既存顧客フォロー、提案書作成などを担当いただきます。未経験者歓迎、研修制度あり。</p>
        </div>
      </div>
      <div class="policy-item">
        <span class="policy-num">02</span>
        <div>
          <h4>人材コーディネーター（正社員）</h4>
          <p>企業と求職者のマッチング業務、面談・フォロー対応を行います。人材業界経験者優遇。</p>
        </div>
      </div>
    </div>
    <div style="margin-top:2rem;">
      <a href="/contact" class="btn btn-primary">採用に関するお問い合わせ</a>
    </div>
  </div>
</section>
<!-- /wp:html -->
