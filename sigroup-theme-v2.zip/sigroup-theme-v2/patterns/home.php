<?php
/**
 * Title: Home
 * Slug: sigroup-theme/home
 * Categories: featured
 */
?>
<!-- wp:html -->

<!-- HERO -->
<section class="hero-section">
  <div class="hero-inner">
    <div class="hero-text">
      <span class="hero-tagline">Business design &amp; execution</span>
      <h1 class="hero-title">営業力と人財力で、<br>現場の成果まで設計する。</h1>
      <p class="hero-body">SIgroup株式会社は、労働者派遣・有料職業紹介事業を通じて、企業の成長と求職者の活躍を支援します。</p>
      <div style="display:flex;gap:0.75rem;flex-wrap:wrap;">
        <a href="/contact" class="btn btn-primary">お問い合わせ</a>
        <a href="/company" class="btn btn-outline">会社概要</a>
      </div>
    </div>
    <div class="hero-image-wrap">
      <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&h=675&fit=crop" alt="チームで働くビジネスパーソン" width="900" height="675" loading="eager">
    </div>
  </div>
</section>

<!-- NEWS -->
<section class="section section--white">
  <div class="container">
    <span class="section-en">News</span>
    <span class="section-ja">お知らせ</span>
    <div class="news-list">
      <div class="news-item">
        <span class="news-date">2026.05.17</span>
        <span class="news-cat">お知らせ</span>
        <span class="news-title">ウェブサイトをリニューアルしました</span>
      </div>
      <div class="news-item">
        <span class="news-date">2026.04.01</span>
        <span class="news-cat">採用</span>
        <span class="news-title">2027年度新卒採用の応募受付を開始しました</span>
      </div>
      <div class="news-item">
        <span class="news-date">2026.03.15</span>
        <span class="news-cat">事業</span>
        <span class="news-title">新規事業部を設立しました</span>
      </div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="section section--offwhite">
  <div class="container">
    <span class="section-en">Services</span>
    <span class="section-ja">事業内容</span>
    <div class="feature-grid">
      <div class="feature-card">
        <div class="feature-icon">
          <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <h3>労働者派遣事業</h3>
        <p>企業のニーズに合わせた人材を迅速に提供し、現場の即戦力として貢献します。</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        </div>
        <h3>有料職業紹介事業</h3>
        <p>求職者と企業の最適なマッチングを実現し、長期的な成長を支援します。</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">
          <svg viewBox="0 0 24 24"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
        </div>
        <h3>営業代行・支援</h3>
        <p>新規開拓から既存顧客フォローまで、営業プロセス全体を設計・実行します。</p>
      </div>
    </div>
  </div>
</section>

<!-- ABOUT -->
<section class="section section--navy">
  <div class="container">
    <div class="two-col">
      <div>
        <span class="section-en">About Us</span>
        <span class="section-ja">私たちについて</span>
        <p style="color:rgba(255,255,255,0.75);font-size:0.9375rem;margin-bottom:1.5rem;max-width:44ch;">SIgroup株式会社は、大阪を拠点に、営業力と人財力で企業課題を解決するプロフェッショナル集団です。許認可を取得した派遣・紹介事業を通じて、信頼できるパートナーとして寄り添います。</p>
        <a href="/company" class="btn btn-outline">会社概要を見る</a>
      </div>
      <div class="two-col-image">
        <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=900&h=675&fit=crop" alt="SIgroupオフィス" width="900" height="675" loading="lazy">
      </div>
    </div>
  </div>
</section>

<!-- RECRUIT CTA -->
<section class="section section--offwhite">
  <div class="container" style="text-align:center;">
    <span class="section-en">Recruit</span>
    <span class="section-ja" style="text-align:center;display:block;">採用情報</span>
    <p style="color:var(--text-muted);font-size:0.9375rem;margin-bottom:2rem;max-width:44ch;margin-inline:auto;">リモートワーク可・副業OK・フレックスタイム制。あなたのライフスタイルに合わせた働き方を実現できます。</p>
    <a href="/recruit" class="btn btn-primary">採用情報を見る</a>
  </div>
</section>

<!-- /wp:html -->
