<?php
/**
 * Title: Company
 * Slug: sigroup-theme/company
 * Categories: page
 */
?>
<!-- wp:html -->
<div class="page-header">
  <div class="page-header-inner">
    <div>
      <span class="section-en">Company</span>
      <span class="section-ja">会社概要</span>
      <p>所在地、役員、資本金、事業内容、許認可情報など、法人として確認されやすい情報を一覧化しています。</p>
    </div>
    <div class="page-header-img">
      <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1000&h=560&fit=crop" alt="オフィスイメージ" width="1000" height="560" loading="lazy">
    </div>
  </div>
</div>

<section class="section section--white">
  <div class="container">
    <span class="section-en">Basic Info</span>
    <span class="section-ja">会社の基本情報</span>
    <div class="info-table-wrap">
      <table class="info-table">
        <tr><th>会社名</th><td>SIgroup株式会社</td></tr>
        <tr><th>代表者</th><td>代表取締役 鈴木 太郎</td></tr>
        <tr><th>所在地</th><td>〒542-0081 大阪府大阪市中央区南船場二丁目1番3号</td></tr>
        <tr><th>資本金</th><td>5,000万円</td></tr>
        <tr><th>従業員数</th><td>25名（派遣スタッフ除く）</td></tr>
        <tr><th>事業内容</th><td>労働者派遣事業・有料職業紹介事業・営業代行支援</td></tr>
        <tr><th>主要取引先</th><td>大手製造業、IT企業、物流企業など</td></tr>
      </table>
    </div>
  </div>
</section>

<section class="section section--offwhite">
  <div class="container">
    <span class="section-en">License</span>
    <span class="section-ja">許認可・法務情報</span>
    <div class="info-table-wrap">
      <table class="info-table">
        <tr><th>労働者派遣事業許可番号</th><td>派27-123456</td></tr>
        <tr><th>有料職業紹介事業許可番号</th><td>27-ユ-123456</td></tr>
      </table>
    </div>
  </div>
</section>
<!-- /wp:html -->
