<?php
/**
 * Title: Privacy
 * Slug: sigroup-theme/privacy
 * Categories: page
 */
?>
<!-- wp:html -->
<div class="page-header">
  <div class="page-header-inner">
    <div>
      <span class="section-en">Privacy Policy</span>
      <span class="section-ja">個人情報保護方針</span>
      <p>当社は個人情報の適切な取得・利用・保管を行い、法令や規範に基づいて継続的な見直しを行います。</p>
    </div>
    <div class="page-header-img">
      <img src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=1000&h=560&fit=crop" alt="セキュリティとデータ保護" width="1000" height="560" loading="lazy">
    </div>
  </div>
</div>

<section class="section section--white">
  <div class="container">
    <span class="section-en">Policy</span>
    <span class="section-ja">基本方針</span>
    <div class="policy-list">
      <div class="policy-item">
        <span class="policy-num">01</span>
        <div><h4>法令・規範の遵守</h4><p>個人情報保護に関する法令、国が定める指針その他の規範を遵守します。</p></div>
      </div>
      <div class="policy-item">
        <span class="policy-num">02</span>
        <div><h4>個人情報の適法な取得</h4><p>適法かつ公正な手段により個人情報を取得し、取得目的を明示します。</p></div>
      </div>
      <div class="policy-item">
        <span class="policy-num">03</span>
        <div><h4>目的外利用の禁止</h4><p>取得した個人情報は、取得時に示した利用目的の範囲内でのみ利用します。</p></div>
      </div>
      <div class="policy-item">
        <span class="policy-num">04</span>
        <div><h4>安全管理措置</h4><p>個人情報への不正アクセス、漏えい、滅失、毀損の防止に努めます。</p></div>
      </div>
      <div class="policy-item">
        <span class="policy-num">05</span>
        <div><h4>第三者提供の制限</h4><p>法令に基づく場合を除き、本人の同意なく第三者へ提供しません。</p></div>
      </div>
    </div>
  </div>
</section>

<section class="section section--offwhite">
  <div class="container">
    <span class="section-en">Contact</span>
    <span class="section-ja">個人情報に関するお問い合わせ</span>
    <div class="contact-grid">
      <div class="contact-card">
        <h3>個人情報保護管理者</h3>
        <p>SIgroup株式会社 管理本部長</p>
        <p style="margin-top:1rem;"><strong>📧 メール</strong><br>privacy@si-group-inc.com</p>
      </div>
      <div class="contact-card">
        <h3>開示・訂正・削除のご請求</h3>
        <p>個人情報の開示・訂正・削除・利用停止をご希望の方は、下記窓口までご連絡ください。</p>
        <p style="margin-top:1rem;"><a href="/contact" class="btn btn-primary" style="font-size:0.875rem;">お問い合わせフォームへ</a></p>
      </div>
    </div>
  </div>
</section>
<!-- /wp:html -->
