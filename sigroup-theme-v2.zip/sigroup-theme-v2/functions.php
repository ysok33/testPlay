<?php
function sigroup_v2_setup() {
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_editor_style('assets/theme.css');
}
add_action('after_setup_theme', 'sigroup_v2_setup');

function sigroup_v2_scripts() {
    wp_enqueue_style('sigroup-v2', get_template_directory_uri() . '/assets/theme.css', [], '2.0.0');
}
add_action('wp_enqueue_scripts', 'sigroup_v2_scripts');

function sigroup_mobile_nav_script() { ?>
<script>
document.addEventListener('DOMContentLoaded', function(){
    var t = document.querySelector('.nav-toggle');
    var n = document.querySelector('.site-nav');
    if (t && n) t.addEventListener('click', function(){ n.classList.toggle('is-open'); });
});
</script>
<?php }
add_action('wp_footer', 'sigroup_mobile_nav_script');
?>
