# SIgroup Playground Block Theme

Playground互換を優先して再構成したブロックテーマです。

## 含まれるもの
- theme.json
- functions.php
- templates/index.html
- templates/page.html
- templates/home.html
- templates/front-page.html
- parts/header.html
- parts/footer.html
- patterns/company-profile.php
- assets/theme.css

## 目的
- WordPress Playground で Site Editor 互換を確保する
- 営業用デモのベーステーマとして使う
