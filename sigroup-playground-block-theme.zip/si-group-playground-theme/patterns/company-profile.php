<?php
/**
 * Title: Company Profile
 * Slug: sigroup-playground/company-profile
 * Categories: text
 */
?>
<!-- wp:group {"className":"profile-panel","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
<div class="wp-block-group profile-panel" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:group {"className":"profile-table"} -->
<div class="wp-block-group profile-table"><!-- wp:html -->
<table><tbody>
<tr><td>社名</td><td>SIgroup 株式会社</td></tr>
<tr><td>設立</td><td>平成26年10月</td></tr>
<tr><td>本社所在地</td><td>岡山県岡山市北区厚生町2-11-14 3F 2号</td></tr>
<tr><td>電話番号</td><td>086-238-5396</td></tr>
<tr><td>FAX</td><td>086-238-5397</td></tr>
<tr><td>代表取締役 社長</td><td>角南 慶英</td></tr>
<tr><td>代表取締役 副社長</td><td>稲谷 健太</td></tr>
<tr><td>資本金</td><td>2,000万円</td></tr>
<tr><td>事業内容</td><td>労働者派遣事業 / 有料職業紹介事業 / 通信事業 / イベント事業</td></tr>
<tr><td>取引銀行</td><td>中国銀行 / 香川銀行 / 日本政策金融公庫</td></tr>
<tr><td>主要取引先</td><td>日本放送協会 / SBモバイルサービス株式会社 / ソフトバンク株式会社</td></tr>
<tr><td>派遣許可番号</td><td>第33-300657</td></tr>
<tr><td>紹介許可番号</td><td>第33-ユ-300342</td></tr>
<tr><td>適格請求書番号</td><td>T3260003001669</td></tr>
</tbody></table>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->
