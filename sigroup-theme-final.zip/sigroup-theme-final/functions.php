<?php
function sigroup_theme_setup() {
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_editor_style('assets/theme.css');
}
add_action('after_setup_theme', 'sigroup_theme_setup');

function sigroup_theme_enqueue_styles() {
    wp_enqueue_style('sigroup-theme-style', get_template_directory_uri() . '/assets/theme.css', array(), '1.0.3');
    wp_enqueue_style('noto-sans-jp', 'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'sigroup_theme_enqueue_styles');
?>
