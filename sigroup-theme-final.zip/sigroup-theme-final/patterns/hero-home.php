<?php
/**
 * Title: Hero Home
 * Slug: sigroup-theme/hero-home
 * Categories: featured
 */
?>

<!-- wp:group {"className":"hero-section"} -->
<div class="wp-block-group hero-section">
    <!-- wp:group {"className":"hero-content"} -->
    <div class="wp-block-group hero-content">
        <!-- wp:group {"className":"hero-text"} -->
        <div class="wp-block-group hero-text">
            <!-- wp:paragraph {"className":"tagline"} -->
            <p class="tagline">Business design &amp; execution</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":1} -->
            <h1>営業力と人財力で、<br>現場の成果まで設計する。</h1>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>SIgroup株式会社は、労働者派遣・有料職業紹介事業を通じて、企業の成長と求職者の活躍を支援します。</p>
            <!-- /wp:paragraph -->

            <!-- wp:buttons -->
            <div class="wp-block-buttons">
                <!-- wp:button -->
                <div class="wp-block-button"><a class="wp-block-button__link" href="/contact">お問い合わせ</a></div>
                <!-- /wp:button -->
            </div>
            <!-- /wp:buttons -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"hero-image"} -->
        <div class="wp-block-group hero-image">
            <!-- wp:image -->
            <figure class="wp-block-image"><img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop" alt="チームで働くビジネスパーソン"/></figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->
