<?php
/**
 * Title: Company Info
 * Slug: sigroup-theme/company-info
 * Categories: page
 */
?>

<!-- wp:group {"className":"page-header"} -->
<div class="wp-block-group page-header">
    <!-- wp:group {"className":"page-header-content"} -->
    <div class="wp-block-group page-header-content">
        <!-- wp:group -->
        <div class="wp-block-group">
            <!-- wp:paragraph {"className":"tagline"} -->
            <p class="tagline">Company</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":1} -->
            <h1>会社情報を、信頼が伝わる形で整理する。</h1>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>所在地、役員、資本金、事業内容、許認可情報など、法人として確認されやすい情報を一覧化しています。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"page-hero-image"} -->
        <div class="wp-block-group page-hero-image">
            <!-- wp:image -->
            <figure class="wp-block-image"><img src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=1000&h=600&fit=crop" alt="会社内を表現するオフィスイメージ"/></figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">会社の基本情報</h2>
    <!-- /wp:heading -->

    <!-- wp:table {"className":"info-table"} -->
    <figure class="wp-block-table info-table"><table><tbody>
        <tr><th>初回の企業認定</th><td>平成28年（設立5年目）で有料職業紹介所への切り替えを認可されました</td></tr>
        <tr><th>所在地</th><td>大阪府大阪市中央区南船場二丁目1番3号</td></tr>
        <tr><th>代表者</th><td>代表取締役 鈴木 太郎</td></tr>
        <tr><th>資本金</th><td>5,000万円</td></tr>
        <tr><th>従業員数</th><td>25名（派遣スタッフ除く）</td></tr>
        <tr><th>主要取引先</th><td>大手製造業、IT企業、物流企業など</td></tr>
    </tbody></table></figure>
    <!-- /wp:table -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">許認可・法務情報</h2>
    <!-- /wp:heading -->

    <!-- wp:table {"className":"info-table"} -->
    <figure class="wp-block-table info-table"><table><tbody>
        <tr><th>派遣・紹介業に必要な許可番号</th><td>派遣業許認可番号は守られながらも明記されていません</td></tr>
        <tr><th>有料職業紹介事業許可番号</th><td>27-ユ-123456（仮）</td></tr>
        <tr><th>労働者派遣事業許可番号</th><td>派27-123456（仮）</td></tr>
    </tbody></table></figure>
    <!-- /wp:table -->
</div>
<!-- /wp:group -->
