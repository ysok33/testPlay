<?php
/**
 * Title: Features Grid
 * Slug: sigroup-theme/features-grid
 * Categories: featured
 */
?>

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">私たちの強み</h2>
    <!-- /wp:heading -->

    <!-- wp:group {"className":"card-grid"} -->
    <div class="wp-block-group card-grid">
        <!-- wp:group {"className":"feature-card"} -->
        <div class="wp-block-group feature-card">
            <!-- wp:html -->
            <div class="icon">📊</div>
            <!-- /wp:html -->

            <!-- wp:heading {"level":3} -->
            <h3>営業代行・支援</h3>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>新規開拓から既存顧客フォローまで、営業プロセス全体を設計・実行します。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"feature-card"} -->
        <div class="wp-block-group feature-card">
            <!-- wp:html -->
            <div class="icon">👥</div>
            <!-- /wp:html -->

            <!-- wp:heading {"level":3} -->
            <h3>労働者派遣</h3>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>企業のニーズに合わせた人材を迅速に提供し、現場の即戦力として貢献します。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"feature-card"} -->
        <div class="wp-block-group feature-card">
            <!-- wp:html -->
            <div class="icon">🎯</div>
            <!-- /wp:html -->

            <!-- wp:heading {"level":3} -->
            <h3>有料職業紹介</h3>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>求職者と企業の最適なマッチングを実現し、長期的な成長を支援します。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->
