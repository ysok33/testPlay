<?php
/**
 * Title: Recruit Page
 * Slug: sigroup-theme/recruit-page
 * Categories: page
 */
?>

<!-- wp:group {"className":"page-header"} -->
<div class="wp-block-group page-header">
    <!-- wp:group {"className":"page-header-content"} -->
    <div class="wp-block-group page-header-content">
        <!-- wp:group -->
        <div class="wp-block-group">
            <!-- wp:paragraph {"className":"tagline"} -->
            <p class="tagline">Recruit</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":1} -->
            <h1>柔軟な働き方と、成長できる環境を両立する。</h1>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>リモートワーク可、副業OK、フレックスタイム制。あなたのライフスタイルに合わせて働ける環境を用意しています。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"page-hero-image"} -->
        <div class="wp-block-group page-hero-image">
            <!-- wp:image -->
            <figure class="wp-block-image"><img src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=1000&h=600&fit=crop" alt="チームで働く多様なメンバー"/></figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">働く環境</h2>
    <!-- /wp:heading -->

    <!-- wp:columns -->
    <div class="wp-block-columns">
        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"feature-card"} -->
            <div class="wp-block-group feature-card">
                <!-- wp:html -->
                <div class="icon">🏠</div>
                <!-- /wp:html -->

                <!-- wp:heading {"level":3} -->
                <h3>リモートワーク可</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p>職種により在宅勤務・出社のハイブリッド勤務が選択可能です。</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"feature-card"} -->
            <div class="wp-block-group feature-card">
                <!-- wp:html -->
                <div class="icon">⏰</div>
                <!-- /wp:html -->

                <!-- wp:heading {"level":3} -->
                <h3>フレックスタイム制</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p>コアタイムなしのフルフレックス制度を導入しています。</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"feature-card"} -->
            <div class="wp-block-group feature-card">
                <!-- wp:html -->
                <div class="icon">💼</div>
                <!-- /wp:html -->

                <!-- wp:heading {"level":3} -->
                <h3>副業OK</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p>事前申請により副業・兼業が可能です。</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">募集職種</h2>
    <!-- /wp:heading -->

    <!-- wp:group {"className":"card"} -->
    <div class="wp-block-group card">
        <!-- wp:heading {"level":3} -->
        <h3>営業職（正社員・契約社員）</h3>
        <!-- /wp:heading -->

        <!-- wp:paragraph -->
        <p>新規開拓営業、既存顧客フォロー、提案書作成などを担当いただきます。未経験者歓迎、研修制度あり。</p>
        <!-- /wp:paragraph -->
    </div>
    <!-- /wp:group -->

    <!-- wp:group {"className":"card"} -->
    <div class="wp-block-group card">
        <!-- wp:heading {"level":3} -->
        <h3>人材コーディネーター（正社員）</h3>
        <!-- /wp:heading -->

        <!-- wp:paragraph -->
        <p>企業と求職者のマッチング業務、面談・フォロー対応を行います。人材業界経験者優遇。</p>
        <!-- /wp:paragraph -->
    </div>
    <!-- /wp:group -->

    <!-- wp:buttons -->
    <div class="wp-block-buttons">
        <!-- wp:button -->
        <div class="wp-block-button"><a class="wp-block-button__link" href="/contact">採用に関するお問い合わせ</a></div>
        <!-- /wp:button -->
    </div>
    <!-- /wp:buttons -->
</div>
<!-- /wp:group -->
