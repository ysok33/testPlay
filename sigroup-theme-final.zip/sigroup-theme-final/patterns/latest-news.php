<?php
/**
 * Title: Latest News
 * Slug: sigroup-theme/latest-news
 * Categories: featured
 */
?>

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">お知らせ</h2>
    <!-- /wp:heading -->

    <!-- wp:group {"className":"news-list"} -->
    <div class="wp-block-group news-list">
        <!-- wp:group {"className":"news-item"} -->
        <div class="wp-block-group news-item">
            <!-- wp:paragraph {"className":"news-date"} -->
            <p class="news-date">2026.05.17</p>
            <!-- /wp:paragraph -->

            <!-- wp:paragraph {"className":"news-title"} -->
            <p class="news-title">ウェブサイトをリニューアルしました</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"news-item"} -->
        <div class="wp-block-group news-item">
            <!-- wp:paragraph {"className":"news-date"} -->
            <p class="news-date">2026.04.01</p>
            <!-- /wp:paragraph -->

            <!-- wp:paragraph {"className":"news-title"} -->
            <p class="news-title">新規事業部を設立しました</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->
