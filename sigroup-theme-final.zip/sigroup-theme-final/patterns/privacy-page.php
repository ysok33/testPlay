<?php
/**
 * Title: Privacy Policy Page
 * Slug: sigroup-theme/privacy-page
 * Categories: page
 */
?>

<!-- wp:group {"className":"page-header"} -->
<div class="wp-block-group page-header">
    <!-- wp:group {"className":"page-header-content"} -->
    <div class="wp-block-group page-header-content">
        <!-- wp:group -->
        <div class="wp-block-group">
            <!-- wp:paragraph {"className":"tagline"} -->
            <p class="tagline">Privacy</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":1} -->
            <h1>個人情報を、取得から管理まで適切に扱う。</h1>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>当社は、個人情報の適切な取得、利用、保管を行い、法令や規則に基づいて継続的な見直しを行います。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"page-hero-image"} -->
        <div class="wp-block-group page-hero-image">
            <!-- wp:image -->
            <figure class="wp-block-image"><img src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=1000&h=600&fit=crop" alt="セキュリティとデータ保護のイメージ"/></figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">基本方針</h2>
    <!-- /wp:heading -->

    <!-- wp:list -->
    <ul>
        <li>法令・規範の遵守<br>個人情報保護に関する法令、国が定める指針その他の規範を遵守します。</li>
        <li>個人情報の取得<br>適法かつ公正な手段により個人情報を取得します。</li>
        <li>個人情報の利用<br>取得した個人情報は、取得の際に示した利用目的の範囲内で利用します。</li>
        <li>個人情報の安全管理<br>個人情報への不正アクセス、個人情報の漏えい、滅失又はき損の防止及び是正に努めます。</li>
    </ul>
    <!-- /wp:list -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:heading {"level":2,"className":"section-title"} -->
    <h2 class="section-title">運用姿勢</h2>
    <!-- /wp:heading -->

    <!-- wp:columns -->
    <div class="wp-block-columns">
        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"card"} -->
            <div class="wp-block-group card">
                <!-- wp:heading {"level":3} -->
                <h3>お問い合わせや採用申込にて取得した個人情報について</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p>ご提供いただいた情報は、お問い合わせへの対応、採用選考、サービス提供の目的にのみ使用します。第三者への提供は法令に基づく場合を除き行いません。</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"card"} -->
            <div class="wp-block-group card">
                <!-- wp:heading {"level":3} -->
                <h3>個人情報保護管理者</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p>SIgroup株式会社<br>管理本部長<br>お問い合わせ: privacy@si-group-inc.com</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->
</div>
<!-- /wp:group -->
