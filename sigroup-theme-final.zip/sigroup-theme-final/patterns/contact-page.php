<?php
/**
 * Title: Contact Page
 * Slug: sigroup-theme/contact-page
 * Categories: page
 */
?>

<!-- wp:group {"className":"page-header"} -->
<div class="wp-block-group page-header">
    <!-- wp:group {"className":"page-header-content"} -->
    <div class="wp-block-group page-header-content">
        <!-- wp:group -->
        <div class="wp-block-group">
            <!-- wp:paragraph {"className":"tagline"} -->
            <p class="tagline">Contact</p>
            <!-- /wp:paragraph -->

            <!-- wp:heading {"level":1} -->
            <h1>事業相談と採用相談の窓口を分けず、まず相談しやすくする。</h1>
            <!-- /wp:heading -->

            <!-- wp:paragraph -->
            <p>事業のご相談、採用に関するお問い合わせの両方を受け付けています。内容に応じて担当よりご案内します。</p>
            <!-- /wp:paragraph -->
        </div>
        <!-- /wp:group -->

        <!-- wp:group {"className":"page-hero-image"} -->
        <div class="wp-block-group page-hero-image">
            <!-- wp:image -->
            <figure class="wp-block-image"><img src="https://images.unsplash.com/photo-1556761175-b413da4baf72?w=1000&h=600&fit=crop" alt="相談を受けるビジネスパーソン"/></figure>
            <!-- /wp:image -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"content-section"} -->
<div class="wp-block-group content-section">
    <!-- wp:columns -->
    <div class="wp-block-columns">
        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"card"} -->
            <div class="wp-block-group card">
                <!-- wp:heading {"level":3} -->
                <h3>事業相談</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p>営業代行、人材派遣、業務効率化など、事業に関するご相談はこちらからお問い合わせください。</p>
                <!-- /wp:paragraph -->

                <!-- wp:paragraph -->
                <p><strong>📧 メール:</strong> business@si-group-inc.com</p>
                <!-- /wp:paragraph -->

                <!-- wp:paragraph -->
                <p><strong>📞 電話:</strong> 06-1234-5678（平日 9:00-18:00）</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->

        <!-- wp:column -->
        <div class="wp-block-column">
            <!-- wp:group {"className":"card"} -->
            <div class="wp-block-group card">
                <!-- wp:heading {"level":3} -->
                <h3>面在地</h3>
                <!-- /wp:heading -->

                <!-- wp:paragraph -->
                <p><strong>所在地:</strong><br>〒542-0081<br>大阪府大阪市中央区南船場二丁目1番3号</p>
                <!-- /wp:paragraph -->

                <!-- wp:paragraph -->
                <p><strong>アクセス:</strong><br>地下鉄御堂筋線「心斎橋駅」より徒歩5分</p>
                <!-- /wp:paragraph -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:column -->
    </div>
    <!-- /wp:columns -->
</div>
<!-- /wp:group -->
