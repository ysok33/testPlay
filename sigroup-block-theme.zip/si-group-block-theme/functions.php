<?php
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('sigroup-fonts', 'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;800&family=Newsreader:opsz,wght@6..72,500;6..72,700&display=swap', [], null);
    wp_enqueue_style('sigroup-style', get_stylesheet_directory_uri() . '/assets/theme.css', ['sigroup-fonts'], filemtime(get_theme_file_path('/assets/theme.css')));
});

add_action('after_setup_theme', function () {
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_editor_style('assets/theme.css');
});
