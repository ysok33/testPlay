<?php
/**
 * Title: Privacy Policy Full
 * Slug: sigroup/privacy-policy
 * Categories: text
 */
?>
<!-- wp:group {"className":"policy-card","style":{"spacing":{"padding":{"top":"2rem","right":"2rem","bottom":"2rem","left":"2rem"}}}} -->
<div class="wp-block-group policy-card" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:list -->
<ul><li>個人情報は、各種契約収納代行事業並びに社員の雇用や人事管理上、必要な範囲に限定して適切に取得・利用・提供を行います。また目的外利用は行わないと同時に、これらを防止するための効果的な対策を実施します。</li><li>個人情報の取り扱いに関する法令、国が定める指針その他の規範を遵守します。</li><li>個人情報の漏えい、滅失、又はき損等の防止及び是正に関しては、合理的な安全対策を講じ、最新の技術動向に併せた経営資源を投入し、個人情報のセキュリティ体制を継続的に向上させます。</li><li>個人情報の取り扱いや当社の個人情報保護マネジメントシステムに対する、本人からの苦情や相談を受け付け、迅速・的確に対応します。また、そのための体制を整備します。</li><li>個人情報保護マネジメントシステムを適時・適切に見直し、その改善を継続的に行ないます。</li></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">個人情報保護方針に関するお問い合わせ先</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>受付時間10：00～18：00 月曜日～金曜日</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>（但し祝祭日、年末年始を除く）</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>電話 086-238-5396（担当 角南慶英）</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
