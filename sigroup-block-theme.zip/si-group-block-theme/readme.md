# SIgroup Corporate Theme

## 同梱内容
- WordPressブロックテーマ一式
- front-page / page テンプレート
- header / footer テンプレートパーツ
- 会社概要 / 採用 / privacy 用パターン
- 独自CSS

## 想定運用
1. WordPress Playgroundまたは通常のWordPressへZIPをアップロード
2. 固定ページを作成
   - ホーム
   - 会社概要
   - 採用情報
   - お問い合わせ
   - 個人情報保護方針
3. 固定ページ本文にパターンを挿入
4. ナビゲーションで各固定ページを接続

## 注意
- 画像は外部URL参照です。正式運用前にメディアライブラリへ取り込み推奨。
- 問い合わせフォームは未実装です。
