document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.wp-block-navigation a').forEach((link) => {
    link.setAttribute('target', '_self');
  });
});
