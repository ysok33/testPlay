<?php
/**
 * Title: News and info
 * Slug: shigaku-tokyo-proposal/news-and-info
 * Categories: featured
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"48px","bottom":"32px"}}},"layout":{"type":"constrained","wideSize":"1200px"}} -->
<div class="wp-block-group" style="padding-top:48px;padding-bottom:32px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"58%"} -->
<div class="wp-block-column" style="flex-basis:58%"><!-- wp:paragraph {"className":"shigaku-eyebrow"} -->
<p class="shigaku-eyebrow">News</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xl"} -->
<h2 class="wp-block-heading has-xl-font-size">お知らせを更新しやすく</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":1,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false}} -->
<div class="wp-block-query"><!-- wp:post-template --><!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"24px","bottom":"24px","left":"24px","right":"24px"},"margin":{"top":"16px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="margin-top:16px;padding-top:24px;padding-right:24px;padding-bottom:24px;padding-left:24px"><!-- wp:post-date {"textColor":"muted","fontSize":"xs"} /-->
<!-- wp:post-title {"level":3,"isLink":true,"fontSize":"base"} /--></div>
<!-- /wp:group --><!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"42%"} -->
<div class="wp-block-column" style="flex-basis:42%"><!-- wp:paragraph {"className":"shigaku-eyebrow"} -->
<p class="shigaku-eyebrow">Information</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xl"} -->
<h2 class="wp-block-heading has-xl-font-size">目的別の補助導線</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"},"margin":{"top":"16px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="margin-top:16px;padding-top:28px;padding-right:28px;padding-bottom:28px;padding-left:28px"><!-- wp:heading {"level":3,"fontSize":"lg"} -->
<h3 class="wp-block-heading has-lg-font-size">学校関係者の方へ</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">申請・制度・募集広報に関するページへの入口を集約します。</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"28px","right":"28px"},"margin":{"top":"16px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="margin-top:16px;padding-top:28px;padding-right:28px;padding-bottom:28px;padding-left:28px"><!-- wp:heading {"level":3,"fontSize":"lg"} -->
<h3 class="wp-block-heading has-lg-font-size">保護者・受験生の方へ</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">支援制度、動画案内、よくある質問への導線をわかりやすくします。</p><!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
