<?php
/**
 * Title: Program cards
 * Slug: shigaku-tokyo-proposal/program-cards
 * Categories: featured
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"96px","bottom":"32px"}}},"layout":{"type":"constrained","wideSize":"1200px"}} -->
<div class="wp-block-group" style="padding-top:96px;padding-bottom:32px"><!-- wp:paragraph {"className":"shigaku-eyebrow"} -->
<p class="shigaku-eyebrow">Programs</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xl"} -->
<h2 class="wp-block-heading has-xl-font-size">制度情報を目的別に整理</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">現サイトにある学費軽減・貸付・保護者向け制度の情報を、初見でも理解しやすいカード導線に再編する想定です。</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"24px"},"margin":{"top":"32px"}}}} -->
<div class="wp-block-columns" style="margin-top:32px"><!-- wp:column --><div class="wp-block-column"><!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px"><!-- wp:paragraph {"textColor":"secondary","fontSize":"xl"} -->
<p class="has-secondary-color has-text-color has-xl-font-size">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">保護者向け制度</h3><!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">動画導線も含め、授業料軽減や貸付制度への入口をわかりやすくします。</p><!-- /wp:paragraph --></div>
<!-- /wp:group --></div><!-- /wp:column -->
<!-- wp:column --><div class="wp-block-column"><!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px"><!-- wp:paragraph {"textColor":"secondary","fontSize":"xl"} -->
<p class="has-secondary-color has-text-color has-xl-font-size">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">学費の負担軽減</h3><!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">返還不要の助成制度を、対象校種と手続き単位で分けて案内します。</p><!-- /wp:paragraph --></div>
<!-- /wp:group --></div><!-- /wp:column -->
<!-- wp:column --><div class="wp-block-column"><!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px"><!-- wp:paragraph {"textColor":"secondary","fontSize":"xl"} -->
<p class="has-secondary-color has-text-color has-xl-font-size">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"fontSize":"lg"} --><h3 class="wp-block-heading has-lg-font-size">学費を借りる</h3><!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} --><p class="has-muted-color has-text-color">入学金や学費全般への貸付を、対象者視点で整理します。</p><!-- /wp:paragraph --></div>
<!-- /wp:group --></div><!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
