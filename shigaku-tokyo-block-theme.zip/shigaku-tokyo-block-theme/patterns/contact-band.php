<?php
/**
 * Title: Contact band
 * Slug: shigaku-tokyo-proposal/contact-band
 * Categories: featured
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"48px","bottom":"96px"}}},"layout":{"type":"constrained","wideSize":"1200px"}} -->
<div class="wp-block-group" style="padding-top:48px;padding-bottom:96px"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"48%"} -->
<div class="wp-block-column" style="flex-basis:48%"><!-- wp:group {"className":"shigaku-contact-panel","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-contact-panel" style="padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px"><!-- wp:paragraph {"className":"shigaku-eyebrow","style":{"elements":{"link":{"color":{"text":"#ffffff"}}},"color":{"text":"#ffffffb8"}}} -->
<p class="shigaku-eyebrow has-text-color" style="color:#ffffffb8">Contact</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xl","textColor":"white"} -->
<h2 class="wp-block-heading has-white-color has-text-color has-xl-font-size">制度案内や申請相談の<br>窓口を集約</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"white"} -->
<p class="has-white-color has-text-color">部署別に電話・メール・受付時間を分け、問い合わせの迷いを減らす設計を想定しています。</p>
<!-- /wp:paragraph -->

<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline","textColor":"white","style":{"border":{"color":"rgba(255,255,255,0.28)"},"color":{"background":"rgba(255,255,255,0.08)"}}} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-white-color has-text-color has-background wp-element-button" style="border-color:rgba(255,255,255,0.28);background-color:rgba(255,255,255,0.08)">03-0000-0000</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"52%"} -->
<div class="wp-block-column" style="flex-basis:52%"><!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px"><!-- wp:heading {"level":3,"fontSize":"lg"} -->
<h3 class="wp-block-heading has-lg-font-size">提案時の注意</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul><li>現サイトから取得した正式文言・制度条件・申請日程は別途精査が必要です。</li><li>画像URLの直参照はデモ用途のため、本制作時は自前メディアへ差し替えるべきです。</li><li>フォームや会員機能はこのテーマ雛形には含めていません。</li></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
