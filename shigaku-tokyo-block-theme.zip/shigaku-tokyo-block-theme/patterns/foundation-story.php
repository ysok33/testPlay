<?php
/**
 * Title: Foundation story
 * Slug: shigaku-tokyo-proposal/foundation-story
 * Categories: featured
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"48px","bottom":"32px"}}},"layout":{"type":"constrained","wideSize":"1200px"}} -->
<div class="wp-block-group" style="padding-top:48px;padding-bottom:32px"><!-- wp:columns {"verticalAlignment":"top"} -->
<div class="wp-block-columns are-vertically-aligned-top"><!-- wp:column {"verticalAlignment":"top","width":"54%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:54%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="https://www.shigaku-tokyo.or.jp/wp-content/themes/shigaku/assets/images/otherprogram_img01.jpg" alt="制度案内イメージ"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"shigaku-eyebrow"} -->
<p class="shigaku-eyebrow">Foundation</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"fontSize":"xl"} -->
<h2 class="wp-block-heading has-xl-font-size">私学財団の役割を<br>短く強く伝える</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">現行サイトのメッセージを踏まえ、都内私立学校の教育振興支援という役割をトップページで先に説明する構成です。</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"46%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:46%"><!-- wp:group {"className":"shigaku-panel","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group shigaku-panel" style="padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px"><!-- wp:paragraph {"className":"shigaku-eyebrow"} -->
<p class="shigaku-eyebrow">Why this structure</p>
<!-- /wp:paragraph -->

<!-- wp:list -->
<ul><li>制度の種類より先に、誰のための情報かを示す。</li><li>ニュースは更新性の高い要素として別ブロックへ分離する。</li><li>問い合わせ・資料請求の導線をフッター直前に集約する。</li></ul>
<!-- /wp:list -->

<!-- wp:separator {"backgroundColor":"border","className":"is-style-wide"} -->
<hr class="wp-block-separator has-text-color has-border-color has-alpha-channel-opacity has-border-background-color has-background is-style-wide"/>
<!-- /wp:separator -->

<!-- wp:heading {"level":3,"fontSize":"lg"} -->
<h3 class="wp-block-heading has-lg-font-size">想定する主要導線</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">保護者向け制度 / 学費軽減 / 貸付制度 / 財団概要 / お知らせ</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->
