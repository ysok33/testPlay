<?php
add_action('after_setup_theme', function () {
    add_theme_support('wp-block-styles');
    add_theme_support('editor-styles');
    add_editor_style('assets/css/theme.css');
    add_theme_support('responsive-embeds');
    add_theme_support('custom-spacing');
    add_theme_support('custom-line-height');
    add_theme_support('custom-units');
    add_theme_support('custom-logo');
    register_nav_menus([
        'primary' => 'Primary Navigation',
        'footer' => 'Footer Navigation',
    ]);
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('shigaku-fonts', 'https://fonts.googleapis.com/css2?family=Marcellus&family=Noto+Sans+JP:wght@400;500;700;800&display=swap', [], null);
    wp_enqueue_style('shigaku-theme', get_template_directory_uri() . '/assets/css/theme.css', [], wp_get_theme()->get('Version'));
    wp_enqueue_script('shigaku-theme', get_template_directory_uri() . '/assets/js/theme.js', [], wp_get_theme()->get('Version'), true);
});
